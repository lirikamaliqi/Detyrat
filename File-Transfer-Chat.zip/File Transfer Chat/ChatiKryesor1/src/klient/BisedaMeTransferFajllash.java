package klient;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.rmi.RemoteException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;

import server.ServerInterface;

public class BisedaMeTransferFajllash extends JFrame {
	    private String userName;
	    private  ServerInterface serveri;
	    private  Klient klienti;
	    private JScrollPane paneli1; 
	    private JScrollPane paneli2;
	    private JScrollPane paneli3;
	    private JTextArea mesazhi;//fusha ku shkruhet mesazhi
	    private JTextArea klientetOnline; //fusha ku paraqiten perdoruesit online
	    private JTextArea mesazhetETjera;//fusha per paraqitjen e mesazheve te derguara
	    private JButton butoniDergo;//butoni per dergim te mesazhit
	    private JButton butoniOnline;//butoni per te shfaqur perdoruesit online
	    private JButton butoniBashkangjit;// butoni per zgjedhjen e fajllit per bashkangjitje

		//konstruktori me dy parametra 
	   public BisedaMeTransferFajllash(String userName, ServerInterface serveri) {
		   ndertoDritaren(); 
	       this.userName = userName; 
	       this.serveri = serveri;  
	        try {
	            klienti = new Klient(userName,mesazhetETjera,klientetOnline);//instance e Klientit  
	            serveri.shtoKlient(klienti);//serveri shton klientin  
	        } catch (RemoteException ex) {
	            Logger.getLogger(BisedaMeTransferFajllash.class.getName()).log(Level.SEVERE, null, ex); 
	        }
	        
	    }

	// Metoda ndertoDritaren nderton dritaren grafike per bised dhe transfer fajllash
	    private void ndertoDritaren() {

	        paneli1 = new javax.swing.JScrollPane();
	        mesazhetETjera = new javax.swing.JTextArea(); 
	        paneli2 = new javax.swing.JScrollPane(); 
	        mesazhi = new javax.swing.JTextArea(); 
	        paneli3 = new javax.swing.JScrollPane(); 
	        klientetOnline=new javax.swing.JTextArea();
	        butoniDergo = new javax.swing.JButton(); 
	        butoniOnline = new javax.swing.JButton();
	        butoniBashkangjit = new javax.swing.JButton();

	        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
	        setResizable(false); 

	        mesazhetETjera.setEditable(false); 
	        mesazhetETjera.setColumns(20);
	        mesazhetETjera.setRows(5); 
	        paneli1.setViewportView(mesazhetETjera);

	        mesazhi.setColumns(20);  
	        mesazhi.setRows(5);  
	        paneli2.setViewportView(mesazhi); 
	        
	        klientetOnline.setEditable(false);
	        klientetOnline.setColumns(20);  
	        klientetOnline.setRows(5);  
	        paneli3.setViewportView(klientetOnline);

	        butoniDergo.setText("Dergo");  
	        butoniDergo.addActionListener(new java.awt.event.ActionListener() { 
	            public void actionPerformed(java.awt.event.ActionEvent evt) { 
	            	dergo(); //metoda dergo thirret pas shtypjes se butonit Dergo
	            	mesazhi.setText("");
	            }
	        });
	        mesazhi.addKeyListener(new KeyAdapter(){ 
	            public void keyPressed(KeyEvent evt) { 
	            	
	            	if(evt.getKeyCode() == KeyEvent.VK_ENTER)
	                {
	            		dergo(); //metoda dergo thirret pas shtypjes se tastit Enter
		            	mesazhi.setText("");
	                }
	            }
	        });
	        butoniOnline.setText("Online");  
	        butoniOnline.addActionListener(new java.awt.event.ActionListener() { 
	            public void actionPerformed(java.awt.event.ActionEvent evt) { 
	            	klientetOnline.setText("");
	                kushEshteOnline(evt); // metoda kushEshteOnline thirret pas shtypjes se butonit Online
	            }
	        });
	        
	        butoniBashkangjit.setText("Bashkangjit"); 
	        butoniBashkangjit.addActionListener(new java.awt.event.ActionListener() { 
	            public void actionPerformed(java.awt.event.ActionEvent evt) { 
	                try { 								
	                	bashkangjit(evt);	//metoda bashkangjit thirret pas shtypjes se butonit Bashkangjit	
					} catch (IOException e) {
						
						e.printStackTrace();			
					}
	            }
	        });
	        //paraqiten fushat dhe butonat ne dritaren grafike
	        JLabel labela1=new JLabel();
	        JLabel labela2=new JLabel();
	        JLabel labela3=new JLabel();
	        labela1.setText("Mesazhet e derguara");
	        labela2.setText("Fusha ku shkruhet mesazhi");
	        labela3.setText("Kush eshte online");
	        JPanel paneli4 = new JPanel(new GridLayout(0,3));				
	        paneli4.add(butoniDergo);				
	        paneli4.add(butoniBashkangjit);
	        paneli4.add(butoniOnline);
	        Container cp=getContentPane();
	        cp.setLayout(new GridLayout(0,1));
	        
	        JPanel paneli5 = new JPanel(new BorderLayout());
	        paneli5.add(labela1,BorderLayout.LINE_START);
	        paneli5.add(paneli1,BorderLayout.LINE_END);
	        cp.add(paneli5);
	        
	        JPanel paneli6 = new JPanel(new BorderLayout());
	        paneli6.add(labela2, BorderLayout.LINE_START);
	        paneli6.add(paneli2,BorderLayout.LINE_END);
	        cp.add(paneli6);
	        
	        JPanel paneli7 = new JPanel(new BorderLayout());
	        paneli7.add(labela3, BorderLayout.LINE_START);
	        paneli7.add(paneli3,BorderLayout.LINE_END);
	        cp.add(paneli7);
	        cp.add(paneli4);


	        pack(); 
	        setLocationRelativeTo(null);
	    }
	    //metoda dergo thirret pas shtypjes se butonit dergo per dergim te mesazhit
	    private void dergo() {                                        
	        if(mesazhi.getText().trim().length()>0){ //mesazhi duhet te kete gjatesine me te madhe se 0
	            try {
	                List<KlientInterface> klientet = serveri.merrKlientet(); //merr listen e perdoruesve
	                
	                for (KlientInterface KlientetTjere : klientet)
	                {
	                	KlientetTjere.dergoMesazhin(userName, mesazhi.getText()); //dergo mesazhin perdoruesve
	                }
	                
	            } catch (RemoteException ex) { 
	                JOptionPane.showMessageDialog(this, ex);
	                Logger.getLogger(BisedaMeTransferFajllash.class.getName()).log(Level.SEVERE, null, ex);
	            }
	        }}
	    
	        //Metoda qe thirret kur shtypet butoni online per te pare se kush eshte online 
	        private void kushEshteOnline(ActionEvent evt) {     
	        	 try {
	                 List<KlientInterface> klientet = serveri.merrKlientet(); //merr listen e perdoruesve
	                 String online="";
	                 for (KlientInterface KlientetTjere : klientet) 
	                 {
	                    	 online=online+KlientetTjere.getEmri()+"\n"; // online-ruan emrat e perdoruesve online
	                 }
	                 klientetOnline.setText(online);// shfaq emrat e perdoruesve online
	                 
	                
	             } catch (RemoteException ex) {  
	                 JOptionPane.showMessageDialog(this, ex);
	                 Logger.getLogger(BisedaMeTransferFajllash.class.getName()).log(Level.SEVERE, null, ex);
	             }
	                      
	        }
	        
	     // metoda qe thirret pas shtypjes se butonit Bashkangjit per bashkangjitje te fajllave   
	    private void bashkangjit(java.awt.event.ActionEvent event) throws IOException{
	    	//perzhgjidhet fajlli nga nje dritare
	  
	    	JFileChooser zgjedhFajllin = new JFileChooser(); 
	    	zgjedhFajllin.showOpenDialog(null); 
	    	File fajlli = zgjedhFajllin.getSelectedFile();
	        String emri = fajlli.getName(); 
	        Path lokacioniFajllit = Paths.get( fajlli.getAbsolutePath());
	        byte[] teDhenat = Files.readAllBytes(lokacioniFajllit);//fajlli ruhet ne varg te byteve
	    	
	    					
	    	List<KlientInterface> klientet = serveri.merrKlientet(); //merr listen e perdoruesve
	        
	        for  (KlientInterface KlientetTjere: klientet)  
	        {
	        	KlientetTjere.dergoFajllin(emri, teDhenat);//dergon fajllin
	        	KlientetTjere.dergoMesazhin(userName," "+fajlli.getName());//shfaqet mesazhi me emrin e fajllit
	        }
	        
	  
	    	
	  
	    }
}